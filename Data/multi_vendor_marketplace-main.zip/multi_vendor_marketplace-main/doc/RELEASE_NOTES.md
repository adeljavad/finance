## Module <multi_vendor_marketplace>

#### 14.11.2024
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Odoo Multi Vendor Marketplace
